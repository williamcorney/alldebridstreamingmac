#!/bin/bash

cd ./app

../node/x64/node install.js --add_nodes $1
