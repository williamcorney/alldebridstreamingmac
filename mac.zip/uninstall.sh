#!/bin/bash
#
echo " -> Removing manifest file for Google Chrome"
rm -f ~/Library/Application\ Support/Google/Chrome/NativeMessagingHosts/com.alld.node.json
echo " -> Removing manifest file for Chromium"
rm -f ~/Library/Application\ Support/Chromium/NativeMessagingHosts/com.alld.node.json
echo " -> Removing manifest file for Mozilla Firefox"
rm -f ~/Library/Application\ Support/Mozilla/NativeMessagingHosts/com.alld.node.json
echo " -> Removing executables"
rm -f -r ~/com.alld.node

echo ">>> Native Client is removed <<<".
