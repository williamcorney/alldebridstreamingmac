#!/usr/bin/env bash
clear
echo This Script will install the alldebrid streaming plugin for Chrome on OSX
read -p "Press enter to continue"
#Create folder for plugin
mkdir $HOME/com.alld.node
#Create Nativemessaging config files for Google Chrome
mkdir "$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
cp com.alld.node.json "$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
#Copy necessary files config.js,host.js, messaging.js and run.sh to same folder
cp config.js $HOME/com.alld.node/
cp host.js $HOME/com.alld.node/
cp messaging.js $HOME/com.alld.node/
cp run.sh $HOME/com.alld.node/
clear
echo Script has completed!

echo 







