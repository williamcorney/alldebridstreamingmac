#!/usr/bin/env bash
clear
echo This Script will uninstall Alldebrid Plugin for Chrome (MACOS)
read -p "Press enter to continue"
#Delete alldebrid plugin folder
rm -r $HOME/com.alld.node
#Delete Nativemessaging config file for Google Chrome
rm "$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts/com.alld.node.json"
clear
echo Script has completed!

echo 







