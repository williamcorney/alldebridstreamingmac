/* globals exports */
'use strict';

exports.ids = {
  chrome: [
    'mdjbgnpehbhpibonmjjjbjaoechnlcaf', // Alld officiel
    'cndnfdjmibkjcdaaeahmifgbbnfohjoj', // Alld dev
    'fabpgdekndfhkfmceikbhgpnfglhamfm'
  ],
  firefox: [
    'alldebrid@alldebrid.com', // Alld
  ]
};
