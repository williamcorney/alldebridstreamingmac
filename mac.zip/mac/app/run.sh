#!/usr/bin/env bash
/usr/local/bin/node host.js